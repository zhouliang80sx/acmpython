# IRP
A pure python package exploring computational geometry algorithms that can be applied to route planning.  Initially the algorithms being studied are Delaunay triangulation and Voronoi diagrams.
